---
title: Alchemy
tags:
categories:
date: 2022-12-31
lastMod: 2022-12-31
---
Dream Interpretations

  + Jungian patient with a dream that an eagle was at first flying up to the sky, and then suddenly turned its head and ate its own wings and dropped to earth.

    + [[enantiodromia]]

    + [[Ripley Scroll]]

Symbols

  + Eagle


    + is typically a symbol of the spirit

    + According to Jung: "all the higher mental faculties such as reason, insight, and moral discrimination"

  + Toad
  + Bird of Hermes
    + Mercury

  + Red Lion
    + Sulphur

  + Green Lion
    + mercury, or vitriol or antimony

  + Mercury


    + quicksilver or "sophic mercury" or [[Philosopher's Stone]]

  + The Sun


    + Maleness

    + Sophic Sulphur

    + gold

  + The Moon


    + silver

    + Sophic mercury

  + Dragon


    + Often a solar or phallic emblem

    + Winged Dragon

      + the volatile principle

    + Dragon without wings

      + the fixed principle

[[Alchemical Terms]]

[[Individuation]]

[[Projection]]
